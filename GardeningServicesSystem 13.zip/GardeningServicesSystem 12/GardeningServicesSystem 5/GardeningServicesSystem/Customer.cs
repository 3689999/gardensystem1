﻿using System.Linq;

namespace GardeningServicesSystem
{
    // Simple data class demonstrating encapsulation with public properties
    public class Customer
    {
        // Properties to hold customer details
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }

        // Constructor (can be overloaded if needed)
        public Customer(string name, string address, string phone)
        {
            Name = name;
            Address = address;
            Phone = phone;
        }

        // Method to validate object state
        // Demonstrates logical operators and data integrity checks
        public bool IsValid()
        {
            return !string.IsNullOrWhiteSpace(Name)
                && !string.IsNullOrWhiteSpace(Address)
                && !string.IsNullOrWhiteSpace(Phone)
                && Phone.All(char.IsDigit); // All characters must be digits
        }
    }
}
