﻿using System;
using System.Windows.Forms;

namespace GardeningServicesSystem
{
    public partial class BillForm : Form
    {
        public BillForm()
        {
            InitializeComponent();
            this.Load += BillForm_Load; // Attach load event
        }

        // Load event populates the bill with service data
        private void BillForm_Load(object sender, EventArgs e)
        {
            // Check if customer and services exist (defensive programming)
            if (AppData.CurrentCustomer == null || AppData.Services.Count == 0)
            {
                MessageBox.Show("Missing customer or service data.");
                return;
            }

            dgvBill.Rows.Clear();
            decimal grandTotal = 0;

            // Loop through services and calculate totals (encapsulation + polymorphism)
            foreach (var service in AppData.Services)
            {
                string description = service.Description;
                string quantity = service.QuantityDisplay;
                string rate = service.Rate.ToString("C");
                decimal cost = service.CalculateCost(); // polymorphic method call

                dgvBill.Rows.Add(description, quantity, rate, cost.ToString("C"));
                grandTotal += cost;
            }

            // Display the total cost
            lblTotal.Text = $"Grand Total: {grandTotal:C}";
        }

        private void BillForm_Load_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void lblTotal_Click(object sender, EventArgs e) { }
    }
}
