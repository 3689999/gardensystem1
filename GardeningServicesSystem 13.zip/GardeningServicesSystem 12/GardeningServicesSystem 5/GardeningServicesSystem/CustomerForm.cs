﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace GardeningServicesSystem
{
    public partial class CustomerForm : Form
    {
        // Constructor initializes the form UI
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            // Optional: Initialization logic can be placed here
        }

        // This method validates and saves customer data on button click
        private void btnSaveCustomer_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            name = Regex.Replace(name, @"[^a-zA-Z\s]", ""); // Only letters and spaces
            string address = txtAddress.Text.Trim();
            string phoneNumber = txtPhone.Text.Trim();

            // Clean and format UK phone number (e.g., +44 → 0)
            phoneNumber = Regex.Replace(phoneNumber, @"\D", ""); // Remove non-digit characters
            if (phoneNumber.StartsWith("44") && phoneNumber.Length == 12)
            {
                phoneNumber = "0" + phoneNumber.Substring(2);
            }

            // Validate fields: simple if-else with logical operators
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(phoneNumber))
            {
                MessageBox.Show("Name, address, and phone number are required.", "Missing Fields");
                return;
            }

            // Validate name and address using regular expressions
            if (!Regex.IsMatch(name, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Name should only contain letters and spaces.");
                return;
            }

            if (!Regex.IsMatch(address, @"^[a-zA-Z0-9\s,.-]{5,}$"))
            {
                MessageBox.Show("Please enter a valid address.");
                return;
            }

            // Ensure valid UK phone number format
            if (!Regex.IsMatch(phoneNumber, @"^(01|02|07)\d{9}$"))
            {
                MessageBox.Show("Please enter a valid UK phone number.");
                return;
            }

            // Save data using encapsulated object
            AppData.CurrentCustomer = new Customer(name, address, phoneNumber);
            MessageBox.Show("Customer saved successfully!", "Success");
        }

        // Go back to the Dashboard form (navigation between forms)
        private void btnBackToDashboard_Click(object sender, EventArgs e)
        {
            this.Hide();
            new DashboardForm().Show();
        }

        // Unused event handlers (can be removed or used for additional validation)
        private void txtName_TextChanged(object sender, EventArgs e) { }
        private void txtAddress_TextChanged(object sender, EventArgs e) { }
        private void txtPhone_TextChanged(object sender, EventArgs e) { }
        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
    }
}
