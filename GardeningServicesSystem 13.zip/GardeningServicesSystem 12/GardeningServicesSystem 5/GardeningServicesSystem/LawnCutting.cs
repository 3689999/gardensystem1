﻿using System;

namespace GardeningServicesSystem
{
    // This class demonstrates inheritance by extending the abstract class Service.
    public class LawnCutting : Service
    {
        // Property specific to this subclass: area in square meters.
        public double Size { get; set; }

        // Override of the abstract Description property.
        public override string Description => $"Lawn Cutting ({Size} sq.m)";

        // Override of the abstract QuantityDisplay property.
        public override string QuantityDisplay => Size.ToString();

        // Fixed rate for lawn cutting per square meter.
        public override decimal Rate => 0.5m;

        // Constructor with a parameter to initialize Size.
        // Could be overloaded with different parameters (method overloading).
        public LawnCutting(double size)
        {
            Size = size;
        }

        // Overrides the abstract CalculateCost method.
        // Applies arithmetic operation to calculate the total service cost.
        public override decimal CalculateCost()
        {
            return (decimal)Size * Rate;
        }
    }
}
