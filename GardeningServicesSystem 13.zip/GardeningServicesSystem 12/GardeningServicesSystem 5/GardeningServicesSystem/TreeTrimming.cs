﻿using System;

namespace GardeningServicesSystem
{
    // Inherits from the abstract Service class.
    // Demonstrates polymorphism by providing a different implementation of CalculateCost.
    public class TreeTrimming : Service
    {
        // Property specific to this service: number of trees to trim.
        public int TreeCount { get; set; }

        // Override of the Description to reflect this service type.
        public override string Description => $"Tree Trimming ({TreeCount} trees)";

        // Quantity shown to user.
        public override string QuantityDisplay => TreeCount.ToString();

        // Fixed rate per tree.
        public override decimal Rate => 20m;

        // Constructor to initialize tree count.
        public TreeTrimming(int count)
        {
            TreeCount = count;
        }

        // Polymorphic behavior – this implementation differs from LawnCutting.
        public override decimal CalculateCost()
        {
            return TreeCount * Rate;
        }
    }
}
