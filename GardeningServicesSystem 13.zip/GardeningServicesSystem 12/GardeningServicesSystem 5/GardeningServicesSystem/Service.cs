﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GardeningServicesSystem
{
    // Abstract class represents a generic gardening service.
    // Applies abstraction: hiding common service logic behind a shared interface.
    public abstract class Service
    {
        // Abstract property: must be implemented by subclasses.
        public abstract string Description { get; }

        // Abstract property for the rate (price per unit, e.g., per hour or per m²).
        public abstract decimal Rate { get; }

        // Display-friendly version of the quantity.
        public abstract string QuantityDisplay { get; }

        // Abstract method to calculate the cost of a service.
        // Demonstrates method overriding when implemented in subclasses.
        public abstract decimal CalculateCost();
    }
}
