﻿using System;
using System.Windows.Forms;

namespace GardeningServicesSystem
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        // Opens the customer entry form
        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            new CustomerForm().Show();
        }

        // Opens the service selection form
        private void btnAddService_Click(object sender, EventArgs e)
        {
            new ServiceForm().Show();
        }

        // Opens the bill generation form
        private void btnGenerateBill_Click(object sender, EventArgs e)
        {
            new BillForm().Show();
        }

        // Opens the workflow guide form
        private void btnHelp_Click(object sender, EventArgs e)
        {
            WorkflowGuideForm guide = new WorkflowGuideForm();
            guide.ShowDialog(); // This opens the guide window
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            // Optional load-time logic
        }
    }
}
