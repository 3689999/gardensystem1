﻿using System;
using System.Windows.Forms;

namespace GardeningServicesSystem
{
    public partial class ServiceForm : Form
    {
        public ServiceForm()
        {
            InitializeComponent();

            // Add service types to combo box (polymorphic options)
            cmbServiceType.Items.Add("Lawn Cutting");
            cmbServiceType.Items.Add("Tree Trimming");

            // Hide input fields initially (UI logic)
            txtLawnSize.Visible = false;
            txtTreeCount.Visible = false;
        }

        // Triggered when the user clicks to add a service
        private void btnAddService_Click(object sender, EventArgs e)
        {
            if (cmbServiceType.SelectedItem == null)
            {
                MessageBox.Show("Please select a service type.");
                return;
            }

            string selectedService = cmbServiceType.SelectedItem.ToString();

            if (selectedService == "Lawn Cutting")
            {
                // Validate numeric input using TryParse and logical checks
                if (!double.TryParse(txtLawnSize.Text.Trim(), out double lawnSize) || lawnSize <= 0)
                {
                    MessageBox.Show("Please enter a valid lawn size.", "Invalid Input");
                    return;
                }

                // Demonstrates polymorphism: LawnCutting inherits from Service
                AppData.Services.Add(new LawnCutting(lawnSize));
                MessageBox.Show("Lawn Cutting service added.");
                this.Close(); // Close the form after successful addition
            }
            else if (selectedService == "Tree Trimming")
            {
                if (!int.TryParse(txtTreeCount.Text.Trim(), out int treeCount) || treeCount <= 0)
                {
                    MessageBox.Show("Please enter a valid number of trees.", "Invalid Input");
                    return;
                }

                AppData.Services.Add(new TreeTrimming(treeCount));
                MessageBox.Show("Tree Trimming service added.");
                this.Close();
            }
        }

        // Updates visible input fields depending on selected service
        private void cmbServiceType_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = cmbServiceType.SelectedItem?.ToString();

            // Dynamic UI logic using conditionals
            txtLawnSize.Visible = selected == "Lawn Cutting";
            txtTreeCount.Visible = selected == "Tree Trimming";

            // Clear previous values
            txtLawnSize.Text = "";
            txtTreeCount.Text = "";
        }

        // Placeholder for potential validation or behavior
        private void txtLawnSize_TextChanged(object sender, EventArgs e) { }
        private void txtTreeCount_TextChanged(object sender, EventArgs e) { }

        private void ServiceForm_Load(object sender, EventArgs e) { }
    }
}
