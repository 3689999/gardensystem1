﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GardeningServicesSystem
{
    public partial class WorkflowGuideForm : Form
    {
        public WorkflowGuideForm()
        {
            InitializeComponent();
            this.Load += new EventHandler(WorkflowGuideForm_Load); // Ensure the Load event is wired
        }

        private void WorkflowGuideForm_Load(object sender, EventArgs e)
        {
            txtGuide.Text =
                "🌿 Gardening Services Workflow Guide\n\n" +
                "1. Open the system and go to the Dashboard.\n" +
                "2. Click 'Add Customer' to enter client details:\n" +
                "   - Name\n   - Address\n   - Phone (digits only)\n\n" +
                "3. Click 'Select Service' to choose a gardening service:\n" +
                "   - Lawn Cutting (enter area in sq.m)\n" +
                "   - Tree Trimming (enter number of trees)\n\n" +
                "4. After selecting the service, click 'Generate Bill'.\n" +
                "   - The bill will show customer info, service type, and total cost.\n\n" +
                "✔ Make sure to double-check data before generating the bill.\n" +
                "✔ Phone numbers must contain only digits.";
        }

        private void txtGuide_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
