﻿namespace GardeningServicesSystem
{
    partial class WorkflowGuideForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGuide = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtGuide
            // 
            this.txtGuide.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGuide.Location = new System.Drawing.Point(0, 0);
            this.txtGuide.Multiline = true;
            this.txtGuide.Name = "txtGuide";
            this.txtGuide.ReadOnly = true;
            this.txtGuide.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtGuide.Size = new System.Drawing.Size(800, 450);
            this.txtGuide.TabIndex = 0;
            this.txtGuide.TextChanged += new System.EventHandler(this.txtGuide_TextChanged);
            // 
            // WorkflowGuideForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtGuide);
            this.Name = "WorkflowGuideForm";
            this.Text = "WorkflowGuideForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtGuide;
    }
}